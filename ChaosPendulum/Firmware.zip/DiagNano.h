// File: DiagNano.h
// Diagnostic Output Pins for Ardiono Nano 

#ifndef DIAGNANO_H
#define DIAGNANO_H

#define UseDIAGpin5 DDRD |= 0x04;
#define DIAGpin5H PORTD |= 0x04; 
#define DIAGpin5L PORTD &= ~0x04; 
#define DIAGpin5T PIND = 0x04; 

#define UseDIAGpin6 DDRD |= 0x08;
#define DIAGpin6H PORTD |= 0x08; 
#define DIAGpin6L PORTD &= ~0x08; 
#define DIAGpin6T PIND = 0x08; 

#define UseDIAGpin7 DDRD |= 0x10;
#define DIAGpin7H PORTD |= 0x10; 
#define DIAGpin7L PORTD &= ~0x10; 
#define DIAGpin7T PIND = 0x10; 

#define UseDIAGpin8 DDRD |= 0x20;
#define DIAGpin8H PORTD |= 0x20; 
#define DIAGpin8L PORTD &= ~0x20; 
#define DIAGpin8T PIND = 0x20; 

#define UseDIAGpin9 DDRD |= 0x40;
#define DIAGpin9H PORTD |= 0x40; 
#define DIAGpin9L PORTD &= ~0x40; 
#define DIAGpin9T PIND = 0x40; 

#define UseDIAGpin10 DDRD |= 0x80;
#define DIAGpin10H PORTD |= 0x80; 
#define DIAGpin10L PORTD &= ~0x80; 
#define DIAGpin10T PIND = 0x80;

#define UseDIAGpin11 DDRB |= 0x01;
#define DIAGpin11H PORTB |= 0x01; 
#define DIAGpin11L PORTB &= ~0x01; 
#define DIAGpin11T PINB = 0x01;

#define UseDIAGpin12 DDRB |= 0x02;
#define DIAGpin12H PORTB |= 0x02; 
#define DIAGpin12L PORTB &= ~0x02; 
#define DIAGpin12T PINB = 0x02;

#define UseDIAGpin13 DDRB |= 0x04;
#define DIAGpin13H PORTB |= 0x04; 
#define DIAGpin13L PORTB &= ~0x04; 
#define DIAGpin13T PINB = 0x04;

#define UseDIAGpin14 DDRB |= 0x08;
#define DIAGpin14H PORTB |= 0x08; 
#define DIAGpin14L PORTB &= ~0x08; 
#define DIAGpin14T PINB = 0x08;

#define UseDIAGpin15 DDRB |= 0x10;
#define DIAGpin15H PORTB |= 0x10; 
#define DIAGpin15L PORTB &= ~0x10; 
#define DIAGpin15T PINB = 0x10;

#define UseDIAGpin16 DDRB |= 0x20;
#define DIAGpin16H PORTB |= 0x20; 
#define DIAGpin16L PORTB &= ~0x20; 
#define DIAGpin16T PINB = 0x20;

#define UseDIAGpin19 DDRC |= 0x01;
#define DIAGpin19H PORTC |= 0x01; 
#define DIAGpin19L PORTC &= ~0x01; 
#define DIAGpin19T PINC = 0x01;

#define UseDIAGpin20 DDRC |= 0x02;
#define DIAGpin20H PORTC |= 0x02; 
#define DIAGpin20L PORTC &= ~0x02; 
#define DIAGpin20T PINC = 0x02;

#define UseDIAGpin21 DDRC |= 0x04;
#define DIAGpin21H PORTC |= 0x04; 
#define DIAGpin21L PORTC &= ~0x04; 
#define DIAGpin21T PINC = 0x04;

#define UseDIAGpin22 DDRC |= 0x08;
#define DIAGpin22H PORTC |= 0x08; 
#define DIAGpin22L PORTC &= ~0x08; 
#define DIAGpin22T PINC = 0x08;

#define UseDIAGpin23 DDRC |= 0x10;
#define DIAGpin23H PORTC |= 0x10; 
#define DIAGpin23L PORTC &= ~0x10; 
#define DIAGpin23T PINC = 0x10;

#define UseDIAGpin24 DDRC |= 0x20;
#define DIAGpin24H PORTC |= 0x20; 
#define DIAGpin24L PORTC &= ~0x20; 
#define DIAGpin24T PINC = 0x20;

#endif